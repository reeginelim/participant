// @ts-ignore
/* eslint-disable */

import * as pet from './pet';
import * as store from './store';
import * as user from './user';
export default {
  pet,
  store,
  user,
};

// @ts-ignore

import * as api from './api';
import * as login from './login';
export default {
  api,
  login,
};

export default {
  'menu.EV & Charger.General Info': 'General',
};

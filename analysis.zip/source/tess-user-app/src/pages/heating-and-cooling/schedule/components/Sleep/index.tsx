import BasicScheduler from '../Basic';

const SleepScheduler = (props) => {
  return <BasicScheduler scene={props.scene} />;
};

export default SleepScheduler;

import { Card } from 'antd';
import BasicScheduler from '../Basic';

const HomeScheduler = (props) => {
  return <BasicScheduler scene={props.scene} />;
};

export default HomeScheduler;

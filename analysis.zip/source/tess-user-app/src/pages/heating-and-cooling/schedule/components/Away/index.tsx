import BasicScheduler from '../Basic';

const AwayScheduler = (props) => {
  return <BasicScheduler scene={props.scene} />;
};

export default AwayScheduler;

import { Card } from 'antd';
import BasicScheduler from '../Basic';

const VacationScheduler = (props) => {
  return <BasicScheduler scene={props.scene} />;
};

export default VacationScheduler;

TODO: All source code should be put in this folder.  Please provide an overview of the structure of this folder and a brief orientation for contributors.
